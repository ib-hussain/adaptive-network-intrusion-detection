# Phase 3 Stage V3 — Recovery, Packet Preflight and Visible Progress

This patch fixes the two symptoms from the latest university log:

1. **24 completed episodes, but a 24-byte PCAP:** it checks that real packet records exist before collecting additional rounds, not merely that a PCAP file exists.
2. **The launcher hanging and retaining the lock:** it uses a dedicated, named Docker capture container, a bounded direct Docker stop and a run-specific lock. It avoids the V2 Compose capture overlay and its problematic stop workflow.

Logging is now a default requirement: UTC-stamped collector log, live heartbeats during generation, per-round generator log, capture-container log, and a JSON status file. A read-only status command supports `--follow`.

**Installation:** `bash install.sh /path/to/adaptive-network-intrusion-detection` (from this extracted patch directory).

**Full runbook:** `docs/STAGE_V3_RECOVERY_RUNBOOK.md`.

**Important:** Already completed Stage V2 episodes cannot have their missing packets recreated. The existing run is preserved for application-level diagnostics; use a new run ID for the first valid network-capture pilot. The previous patch, legacy data, model files and SQLite databases are not modified.

The new PCAP parsing and launcher-contract tests pass locally. The original Stage V2 test suite also passed in a fresh compatibility copy of the uploaded repository. No Docker daemon is available in the current tool environment, so sidecar capture must be proven on the university Ubuntu machine. No research performance is claimed from these tests.
