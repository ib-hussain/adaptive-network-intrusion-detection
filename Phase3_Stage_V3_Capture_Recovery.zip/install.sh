#!/usr/bin/env bash
# Strict additive installer; never overwrites user repo code or experiment artifacts.
set -euo pipefail
SOURCE="$(cd "$(dirname "$0")" && pwd)"
REPO="$(realpath "${1:-$PWD}")"
[[ -f "$REPO/compose.yaml" && -f "$REPO/setup/staged_collect_v2.sh" && -f "$REPO/lab/staged_generate.py" ]] || {
  echo "STOP: $REPO is not the Stage V2 project. No changes made." >&2; exit 2;
}
files=(
  setup/staged_collect_v3.sh
  setup/staged_capture_audit.py
  setup/staged_recover_v2.sh
  setup/staged_v3_status.sh
  setup/staged_train_guard_v3.sh
  tests/test_staged_capture_audit.py
  tests/test_v3_launcher_contract.py
  docs/STAGE_V3_RECOVERY_RUNBOOK.md
)
for f in "${files[@]}"; do
  [[ -f "$SOURCE/$f" ]] || { echo "Missing package file $f" >&2; exit 2; }
  if [[ -e "$REPO/$f" ]] && ! cmp -s "$SOURCE/$f" "$REPO/$f"; then
    echo "STOP: existing modified $REPO/$f differs from patch. No changes made." >&2
    exit 3
  fi
done
for f in "${files[@]}"; do
  mkdir -p "$(dirname "$REPO/$f")"
  if [[ ! -e "$REPO/$f" ]]; then cp -p "$SOURCE/$f" "$REPO/$f"; echo "INSTALLED $f"; else echo "UNCHANGED $f"; fi
done
chmod +x "$REPO/setup/staged_collect_v3.sh" "$REPO/setup/staged_recover_v2.sh" "$REPO/setup/staged_v3_status.sh" "$REPO/setup/staged_train_guard_v3.sh"
for f in "$REPO/setup/staged_collect_v3.sh" "$REPO/setup/staged_recover_v2.sh" "$REPO/setup/staged_v3_status.sh" "$REPO/setup/staged_train_guard_v3.sh"; do bash -n "$f"; done
cd "$REPO"
if [[ -x .venv-cuda/bin/python ]]; then PY=.venv-cuda/bin/python; elif [[ -x .venv/bin/python ]]; then PY=.venv/bin/python; else PY=python3; fi
"$PY" -m unittest discover -s tests -p 'test_staged_capture_audit.py' -v
"$PY" -m unittest discover -s tests -p 'test_v3_launcher_contract.py' -v
printf '\nV3 additive patch installed. No V2 scripts, run journals, PCAP, models, DBs or outputs overwritten.\n'
