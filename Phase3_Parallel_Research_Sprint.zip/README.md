# Parallel Research Sprint Kit — November 2026

This is an **additive overlay** for `adaptive-network-intrusion-detection`. It does not require Git LFS and does not overwrite the old repository modules. It includes three independent parallel workers (sensor audit, CPU Optuna, GPU temporal baseline), an exclusive capture launcher and unit tests.

**Start:** Read `docs/RUNBOOK.md` and execute `./setup/sprint_start.sh pilot_20261113T083155Z_61354 --hpo-trials 30 --gru-epochs 60` after extracting the ZIP into the repository root.

**Key caveat:** This is a lab engineering sprint, not proof of zero-day detection or early-warning performance. All experiments still use bounded, non-malicious request profiles.
