#!/usr/bin/env bash
# Safe, additive installation of Phase 3 Stage V2; never deletes or rewrites data.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
REPO="${1:-$PWD}"
REPO="$(realpath "$REPO")"
[[ -f "$REPO/compose.yaml" && -f "$REPO/src/code/pipeline.py" && -f "$REPO/setup/sprint_hpo.py" ]] || {
 echo "Not the expected Phase 3 repository: $REPO" >&2;exit 1;
}
cd "$REPO"
python3 - "$HERE" "$REPO" <<'PY'
import hashlib, json, pathlib, shutil, sys, datetime
from pathlib import Path
src=Path(sys.argv[1]);root=Path(sys.argv[2]);data=json.loads((src/'install_checksums.json').read_text())
changes=[]; skipped=[]
for rel, expected in data['files'].items():
    target=root/rel
    expected_base=data['baseline'].get(rel)
    current=hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
    if current==expected:skipped.append(rel);continue
    if expected_base is not None and current!=expected_base:
        raise SystemExit(f'STOP: existing file has changed since ZIP snapshot: {rel}. No files modified. Diff and reconcile before applying.')
    if expected_base is None and target.exists():
        raise SystemExit(f'STOP: unexpected pre-existing file: {rel}. No files modified.')
    changes.append((rel,current))
print(f'Safety preflight: {len(changes)} changes, {len(skipped)} already up-to-date')
if not changes:exit(0)
backup=root/'outputs'/'backups'/('staged_v2_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
backup.mkdir(parents=True,exist_ok=False)
for rel,current in changes:
    if current is not None:
        dest=backup/rel;dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(root/rel,dest)
for rel,current in changes:
    target=root/rel;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src/rel,target)
for rel,current in changes:
    newhash=hashlib.sha256((root/rel).read_bytes()).hexdigest()
    assert newhash==data['files'][rel], f'Hash mismatch after copy: {rel}'
(backup/'install_manifest.json').write_text(json.dumps({'installed':list(rel for rel,_ in changes),'original_hashes':{rel:c for rel,c in changes},'source':str(src)},indent=2))
print('Installed safely. Original modified files backed up to:', backup)
PY
chmod +x setup/staged_*.sh
python3 -m py_compile lab/staged_generate.py src/code/features.py src/code/early_warning.py src/code/pipeline.py src/code/temporal_gru_sprint.py setup/staged_zeek.py setup/sprint_hpo.py
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest -q tests/test_stage_v2.py tests/test_early_warning.py tests/test_game.py tests/test_ingest_features.py tests/test_splits.py tests/test_sprint_modules.py
printf '\nPhase 3 Stage V2 installed and tested. No existing data/checkpoints deleted.\n'
