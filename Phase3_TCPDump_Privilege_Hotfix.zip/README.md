# Stage V3: tcpdump restricted-container privilege hotfix

**Observed failure:** `tcpdump: Couldn't change to 'tcpdump' uid=100 gid=101: Operation not permitted`.

**Verified cause:** The image has an entrypoint of `tcpdump`, which attempts to change from root to the `tcpdump` UID/GID by default; the deliberately restricted sidecar removes capabilities needed for that switch.

**Fix:** Add the documented `-Z root` flag to **only** the Stage V3 tcpdump command. Preserve `--cap-drop ALL --cap-add NET_RAW`, `--security-opt no-new-privileges:true`, the existing Docker capture namespace, packet preflight and heartbeat. This runs tcpdump as UID 0 inside a limited-purpose, limited-capability container. It is a bounded exception to the general preference for unprivileged services; it is **not** a fully privileged container.

## Install in Ubuntu terminal

From the project root, with the ZIP copied into the project or `~/Downloads`:

```bash
cd /home/fastlab/deepFakeDetection/adaptive-network-intrusion-detection
unzip -q -o ~/Downloads/Phase3_TCPDump_Privilege_Hotfix.zip -d /tmp/phase3-tcpdump-fix
bash /tmp/phase3-tcpdump-fix/fix_tcpdump_privileges.sh "$PWD"
source .venv-cuda/bin/activate
export PATH=/opt/zeek/bin:$PATH
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
bash -n setup/staged_collect_v3.sh
```

Check no collector is running: `pgrep -af 'staged_collect|tcpdump' || true`; verify `docker ps` works. Do not kill unknown jobs or clear active locks.

## Resume the existing clean pre-collection pilot

```bash
./setup/staged_collect_v3.sh --run-id staged_v3_check_02 --rounds 3 --test-rounds 3 --seed 20261114 --capture --resume
```

The run was initialised but has zero committed episodes and previous header-only PCAPs; the launcher writes a **new** timestamped PCAP, leaving both prior invalid files intact. Its HTTP probe must see packet records *before* generating episodes. Monitor a separate terminal:

```bash
./setup/staged_v3_status.sh staged_v3_check_02 --follow
```

**Only after the pilot succeeds** (24 episodes, 480 observed gateway requests, valid packet-bearing PCAP, no capture hang), proceed:

```bash
./setup/staged_collect_v3.sh --run-id staged_v2_main_01 --rounds 12 --test-rounds 12 --seed 20261115 --capture --resume
```

`staged_v2_main_01` was only initialised in an earlier failure; do not launch the heavy training jobs until collection and independent Zeek/manifest alignment are validated. Check `./setup/staged_v3_status.sh staged_v2_main_01` and use `./setup/staged_train_guard_v3.sh` after validation.

If the probe still fails, preserve the per-run `collector_v3_*.log` and `capture_container_*.log`; it may indicate additional network-namespace or packet permissions limitations. Do not loosen to `--privileged` or modify system-wide Docker security settings blindly.

Ubuntu documentation: https://manpages.ubuntu.com/manpages/noble/man8/tcpdump.8.html ; Docker run capabilities: https://docs.docker.com/engine/containers/run/.
