#!/usr/bin/env bash
# Stage V3 exact-site hotfix: tcpdump's default privilege drop fails in the
# deliberately restricted capture container. -Z root skips the uid/gid switch.
# Applies only to the Stage V3 lab capture launcher; does not change Dockerfile,
# data, checkpoints, snapshots, study DBs or running containers.
set -Eeuo pipefail
REPO="$(realpath "${1:-$PWD}")"
TARGET="$REPO/setup/staged_collect_v3.sh"
if [[ ! -f "$TARGET" || ! -f "$REPO/compose.yaml" ]]; then
  echo 'ERROR: expected a Stage V3 project root containing compose.yaml and setup/staged_collect_v3.sh' >&2
  exit 2
fi
python3 - "$TARGET" <<'PY'
import sys
from pathlib import Path
s = Path(sys.argv[1]).read_text(encoding="utf-8")
original = '"$IMAGE" -i any -p -nn -s 0 -U -w '
fixed = '"$IMAGE" -Z root -i any -p -nn -s 0 -U -w '
required = (
    '--cap-drop ALL --cap-add NET_RAW',
    '--security-opt no-new-privileges:true',
    '--network "container:$GATEWAY_CID"',
    'CAPTURE_PREFLIGHT_FAILED',
    'Capture preflight passed: actual packet records observed',
    'HEARTBEAT',
)
missing = [part for part in required if part not in s]
if missing:
    raise SystemExit(f'ERROR: unexpected launcher version: missing required safety markers {missing}')
if s.count(fixed) == 1 and original not in s:
    print('ALREADY FIXED: tcpdump uses -Z root. No change needed.')
    sys.exit(0)
if s.count(original) != 1 or fixed in s:
    raise SystemExit('ERROR: cannot uniquely find original V3 tcpdump command; no changes made')
print('VERIFIED: expected original Stage V3 tcpdump invocation and restricted capabilities')
PY
if grep -Fq '"$IMAGE" -Z root -i any -p -nn -s 0 -U -w ' "$TARGET"; then
  bash -n "$TARGET"
  echo 'OK: launcher was already fixed; syntax verified.'
  exit 0
fi
BACKUP_DIR="$REPO/outputs/backups/stage_v3_tcpdump_privileges_$(date -u +%Y%m%dT%H%M%SZ)_$$"
mkdir -p "$BACKUP_DIR"
cp -p "$TARGET" "$BACKUP_DIR/staged_collect_v3.sh"
python3 - "$TARGET" <<'PY'
import os,sys,tempfile
from pathlib import Path
p=Path(sys.argv[1]); s=p.read_text(encoding='utf-8')
before='"$IMAGE" -i any -p -nn -s 0 -U -w '
after='"$IMAGE" -Z root -i any -p -nn -s 0 -U -w '
assert s.count(before)==1 and after not in s
st=os.stat(p)
fd,tmp=tempfile.mkstemp(prefix=f'.{p.name}.',suffix='.tmp',dir=p.parent)
try:
    with os.fdopen(fd,'w',encoding='utf-8') as f:
        f.write(s.replace(before,after,1))
        f.flush(); os.fsync(f.fileno())
    os.chmod(tmp,st.st_mode)
    os.replace(tmp,p)
except BaseException:
    if os.path.exists(tmp): os.unlink(tmp)
    raise
print('PATCH APPLIED: tcpdump now starts with -Z root; restricted Docker capabilities unchanged.')
PY
if ! bash -n "$TARGET"; then
  cp -p "$BACKUP_DIR/staged_collect_v3.sh" "$TARGET"
  echo 'ERROR: syntax failure; original launcher restored.' >&2
  exit 1
fi
python3 - "$TARGET" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
assert s.count('"$IMAGE" -Z root -i any -p -nn -s 0 -U -w ') == 1
assert '--cap-drop ALL --cap-add NET_RAW' in s
assert '--security-opt no-new-privileges:true' in s
assert 'Capture preflight passed: actual packet records observed' in s
assert 'HEARTBEAT' in s
print('VERIFIED: patched invocation, isolated capture, preflight gate, timestamped heartbeat.')
PY
printf 'BACKUP: %s\n' "$BACKUP_DIR/staged_collect_v3.sh"
printf 'DATA: old run journals, PCAPs, trained models and logs were not touched.\n'
